

void OLED_One_Time_Configuartion(void);
void OLED_Schedule_And_Event_Control(void);
