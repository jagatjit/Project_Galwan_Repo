



#ifdef __cplusplus
 extern "C" {

 void NRF24L01_One_Time_Configuartion(void);
 void NRF24L01_Schedule_And_Event_Control(void);

 }
 #endif
