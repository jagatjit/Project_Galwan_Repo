/*
 * Radio_RF_Control.c
 *
 *  Created on: Jul 26, 2020
 *      Author: bbsra
 */

#include <stdio.h>
#include "Helper_Function.h"

//#include "Radio_RF_Control.h"
#include "MY_NRF24_main.h"

//#include "nRF24L01.h"
uint64_t TxpipeAddrs = 0x11223344AA;
char myTxData[32] = "Hello World!";
char AckPayload[32];

uint64_t RxpipeAddrs = 0x11223344AA;
char myRxData[50];
char myAckPayload[32] = "Ack by STMF4";




void NRF24L01_One_Time_Configuartion()
{


  NRF24_begin_caller();
  nrf24_DebugUART_Init_caller();

  printRadioSettings();

  //**** TRANSMIT - ACK ****//
  NRF24_stopListening();
  NRF24_openWritingPipe(TxpipeAddrs);
  NRF24_setAutoAck(false);
  NRF24_setChannel(52);
  NRF24_setPayloadSize(32);

//  NRF24_enableDynamicPayloads();
//  NRF24_enableAckPayload();


/*
  // Rx
  NRF24_begin_caller();
  nrf24_DebugUART_Init_caller();

  printRadioSettings();

  NRF24_setAutoAck(false);
  NRF24_setChannel(52);
  NRF24_setPayloadSize(32);
  NRF24_openReadingPipe(1, RxpipeAddrs);

//  NRF24_enableDynamicPayloads();
//  NRF24_enableAckPayload();

  NRF24_startListening();


*/



}



void NRF24L01_Schedule_And_Event_Control()
{
	char serial_console_print[80];

  // Transmit message
  if(NRF24_write(myTxData, 32))
  {
//	NRF24_read(AckPayload, 32);

	sprintf(serial_console_print, "Transmitted Successfully\r\n");
	Print_Debug_Info_UART(serial_console_print);

//	sprintf(serial_console_print, "AckPayload:  %s \r\n", AckPayload);
//	Print_Debug_Info_UART(serial_console_print);

  }

  HAL_Delay(1000);

/*
  // Receive message

  if(NRF24_available())
  {
    NRF24_read(myRxData, 32);
 //   NRF24_writeAckPayload(1, myAckPayload, 32);

    myRxData[32] = '\r'; myRxData[32+1] = '\n';
	sprintf(serial_console_print, "myRxData:  %s \r\n", myRxData);
	Print_Debug_Info_UART(serial_console_print);

//	sprintf(serial_console_print, "myAckPayload:  %s \r\n", myAckPayload);
//	Print_Debug_Info_UART(serial_console_print);

  }


*/


}
