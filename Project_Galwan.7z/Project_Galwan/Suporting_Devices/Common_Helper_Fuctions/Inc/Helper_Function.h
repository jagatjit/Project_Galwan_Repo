

#ifdef __cplusplus
 extern "C" {


void Print_Debug_Info_UART(char print_data[] );

}
#endif
